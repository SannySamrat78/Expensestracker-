import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar } from 'react-native';
import { loadExpenses, saveExpenses, loadSettings, saveSettings } from './src/utils/storage';
import { C, MONTHS } from './src/utils/colors';
import DashboardScreen from './src/screens/DashboardScreen';
import SyncScreen      from './src/screens/SyncScreen';
import AddScreen       from './src/screens/AddScreen';
import HistoryScreen   from './src/screens/HistoryScreen';
import SettingsScreen  from './src/screens/SettingsScreen';

const TABS = [
  { id:'dashboard', icon:'📊', label:'Dashboard' },
  { id:'sync',      icon:'📱', label:'Sync SMS' },
  { id:'add',       icon:'➕', label:'Add' },
  { id:'history',   icon:'📋', label:'History' },
  { id:'settings',  icon:'⚙️',  label:'Settings' },
];

export default function App() {
  const [tab, setTab]           = useState('dashboard');
  const [expenses, setExpenses] = useState([]);
  const [settings, setSettings] = useState({ apiKey:'', bankKeywords:'debited,debit,spent,paid,withdrawn,INR' });
  const [ready, setReady]       = useState(false);
  const [selMonth, setSelMonth] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
  });

  useEffect(() => {
    Promise.all([loadExpenses(), loadSettings()]).then(([exp, set]) => {
      setExpenses(exp); setSettings(set); setReady(true);
    });
  }, []);

  const persist = useCallback(async list => {
    setExpenses(list); await saveExpenses(list);
  }, []);

  const handleSave = useCallback(async newOnes => {
    const keys = new Set(expenses.map(e=>`${e.amount}-${e.date}-${e.merchant}`));
    const deduped = newOnes.filter(e => !keys.has(`${e.amount}-${e.date}-${e.merchant}`));
    if (deduped.length) await persist([...deduped, ...expenses]);
  }, [expenses, persist]);

  const handleDelete = useCallback(async id => {
    await persist(expenses.filter(e => e.id !== id));
  }, [expenses, persist]);

  if (!ready) return (
    <View style={{flex:1,backgroundColor:C.bg,alignItems:'center',justifyContent:'center'}}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
      <Text style={{color:C.textMuted,fontSize:14}}>Loading…</Text>
    </View>
  );

  return (
    <SafeAreaView style={{flex:1,backgroundColor:C.bg}}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
      <View style={{flex:1}}>
        {tab==='dashboard' && <DashboardScreen expenses={expenses} selectedMonth={selMonth} setMonth={setSelMonth} onDelete={handleDelete}/>}
        {tab==='sync'      && <SyncScreen onSave={items=>{handleSave(items);setTab('dashboard');}} settings={settings}/>}
        {tab==='add'       && <AddScreen onSave={handleSave}/>}
        {tab==='history'   && <HistoryScreen expenses={expenses} selectedMonth={selMonth} onDelete={handleDelete}/>}
        {tab==='settings'  && <SettingsScreen settings={settings} onSave={async s=>{setSettings(s);await saveSettings(s);}}/>}
      </View>
      <View style={s.nav}>
        {TABS.map(({id,icon,label}) => {
          const active = tab === id;
          return (
            <TouchableOpacity key={id} style={s.navBtn} onPress={()=>setTab(id)} activeOpacity={0.7}>
              <Text style={{fontSize:20}}>{icon}</Text>
              <Text style={[s.navLbl, active&&s.navLblA]}>{label}</Text>
              {active && <View style={s.dot}/>}
            </TouchableOpacity>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  nav:     {flexDirection:'row',backgroundColor:C.surface,borderTopWidth:1,borderTopColor:C.border,paddingBottom:8,paddingTop:8},
  navBtn:  {flex:1,alignItems:'center',gap:2,paddingTop:2},
  navLbl:  {color:C.textMuted,fontSize:9,fontWeight:'500'},
  navLblA: {color:C.accent,fontWeight:'700'},
  dot:     {width:4,height:4,borderRadius:2,backgroundColor:C.accent,marginTop:1},
});
