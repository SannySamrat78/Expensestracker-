# ExpenseBook — Android APK via GitHub Actions

## What this does
Reads your Android bank SMS locally, parses expenses, shows monthly reports.
APK is built automatically by GitHub when you push this code.

---

## STEP 1 — Create free accounts (if you don't have them)
- GitHub: https://github.com/signup
- Expo: https://expo.dev/signup

---

## STEP 2 — Get your Expo token
1. Go to https://expo.dev
2. Login → click your profile icon (top right) → **Access Tokens**
3. Click **Create Token** → name it "github-actions" → copy the token
4. Save it — you'll need it in Step 4

---

## STEP 3 — Push this code to GitHub
```bash
# On your PC, open terminal in this folder
git init
git add .
git commit -m "Initial ExpenseBook"

# Create a new repo on github.com (name it expense-book)
# Then:
git remote add origin https://github.com/YOUR_USERNAME/expense-book.git
git push -u origin main
```

---

## STEP 4 — Add Expo token to GitHub secrets
1. Go to your GitHub repo
2. Click **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Name: `EXPO_TOKEN`
5. Value: paste your token from Step 2
6. Click **Add secret**

---

## STEP 5 — Trigger the build
The build starts automatically when you push. Or:
1. Go to your repo on GitHub
2. Click **Actions** tab
3. Click **Build Android APK**
4. Click **Run workflow** → **Run workflow**

Wait ~10-15 minutes.

---

## STEP 6 — Download your APK
1. Go to **Actions** tab in your repo
2. Click the completed workflow run
3. Scroll down to **Artifacts**
4. Click **ExpenseBook-APK** to download

---

## STEP 7 — Install on your phone
1. Transfer the APK to your Android phone (WhatsApp, email, USB, Google Drive)
2. On your phone: Settings → Security → **Install unknown apps** → Allow
3. Open the APK file → Install
4. Open ExpenseBook → go to **Sync SMS** → tap **Read Bank SMS**
5. Grant SMS permission → done!

---

## App Features
- 📱 Reads local Android SMS directly (never uploaded)
- 🏦 Auto-detects: AU Bank, HDFC, ICICI, SBI, Axis, Kotak
- 📊 Monthly dashboard with spending chart
- 🔍 Search expenses by merchant/category
- ✏️ Manual add for cash expenses
- 🤖 Optional AI parsing (Settings → add Claude API key)

---

## Troubleshooting

**Build fails with "project not found":**
Run `npx eas init` locally once to register the project, then push again.

**SMS not detected:**
Go to Settings in the app → add your bank's keyword (e.g. "debited").

**APK won't install:**
Enable "Install from unknown sources" in Android Settings → Security.
