import { useState, useCallback } from 'react';
import { PermissionsAndroid, Platform, NativeModules } from 'react-native';
import { parseSMSLocally, isBankSMS, parseWithAI } from '../utils/smsParser';
import { uid } from '../utils/storage';

export function useSMS() {
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  const requestPermission = useCallback(async () => {
    if (Platform.OS !== 'android') {
      setError('SMS reading is only available on Android.');
      return false;
    }
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.READ_SMS,
        {
          title: 'SMS Permission Required',
          message: 'ExpenseBook needs to read your bank SMS messages to automatically track expenses. Your messages are processed locally and never uploaded.',
          buttonPositive: 'Allow',
          buttonNegative: 'Deny',
        }
      );
      if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
        setError('SMS permission denied. Go to Settings → Apps → ExpenseBook → Permissions → SMS → Allow.');
        return false;
      }
      return true;
    } catch (e) {
      setError('Permission error: ' + e.message);
      return false;
    }
  }, []);

  const readSMS = useCallback(async ({ keywords, daysBack, useAI, apiKey }) => {
    setLoading(true);
    setError('');

    const ok = await requestPermission();
    if (!ok) { setLoading(false); return []; }

    // Use native SmsAndroid module (react-native-get-sms-android)
    const SmsAndroid = NativeModules.SmsAndroid;
    if (!SmsAndroid) {
      setError('SMS module not available. Please rebuild the app.');
      setLoading(false);
      return [];
    }

    const minDate = Date.now() - daysBack * 86400000;

    return new Promise(resolve => {
      SmsAndroid.list(
        JSON.stringify({ box: 'inbox', minDate, maxCount: 300 }),
        fail => {
          setError('Could not read SMS: ' + fail);
          setLoading(false);
          resolve([]);
        },
        async (count, smsList) => {
          try {
            const messages = JSON.parse(smsList);
            const bankMsgs = messages.filter(s => isBankSMS(s.body, keywords));

            if (!bankMsgs.length) {
              setError(`No bank SMS found in last ${daysBack} days. Try increasing the period or add keywords in Settings.`);
              setLoading(false);
              resolve([]);
              return;
            }

            let expenses = [];
            if (useAI && apiKey) {
              try {
                const parsed = await parseWithAI(bankMsgs.map(s => s.body), apiKey);
                expenses = parsed.map(e => ({ ...e, id: uid(), source: 'sms_ai' }));
              } catch {
                // fallback to local
                expenses = bankMsgs.flatMap(s =>
                  parseSMSLocally(s.body).map(e => ({ ...e, id: uid(), source: 'sms_local' }))
                );
              }
            } else {
              expenses = bankMsgs.flatMap(s =>
                parseSMSLocally(s.body).map(e => ({ ...e, id: uid(), source: 'sms_local' }))
              );
            }

            setLoading(false);
            resolve(expenses);
          } catch (e) {
            setError('Parse error: ' + e.message);
            setLoading(false);
            resolve([]);
          }
        }
      );
    });
  }, [requestPermission]);

  return { readSMS, loading, error, setError };
}
