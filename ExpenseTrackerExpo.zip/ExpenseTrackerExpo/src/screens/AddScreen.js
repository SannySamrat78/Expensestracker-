import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { C, CATEGORIES, CAT_LIST } from '../utils/colors';
import { uid } from '../utils/storage';

export default function AddScreen({ onSave }) {
  const today = new Date().toISOString().slice(0,10);
  const [amount, setAmount]     = useState('');
  const [merchant, setMerchant] = useState('');
  const [category, setCategory] = useState('Food');
  const [date, setDate]         = useState(today);
  const [note, setNote]         = useState('');
  const [done, setDone]         = useState(false);

  function save() {
    if (!amount||!merchant) return;
    onSave([{id:uid(),amount:parseFloat(amount),merchant,category,date,note,source:'manual'}]);
    setAmount('');setMerchant('');setNote('');setDate(today);setCategory('Food');
    setDone(true); setTimeout(()=>setDone(false),2000);
  }

  return (
    <ScrollView style={s.scroll} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>Add Expense</Text>
      {done && <View style={s.ok}><Text style={{color:'#86EFAC',fontSize:14,fontWeight:'600',textAlign:'center'}}>✓ Saved!</Text></View>}
      <View style={s.card}>
        <Text style={s.lbl}>AMOUNT (₹)</Text>
        <TextInput style={s.bigInput} value={amount} onChangeText={setAmount} keyboardType="numeric" placeholder="0" placeholderTextColor={C.textMuted}/>
        <Text style={[s.lbl,{marginTop:16}]}>MERCHANT</Text>
        <TextInput style={s.input} value={merchant} onChangeText={setMerchant} placeholder="Zomato, Amazon, Petrol…" placeholderTextColor={C.textMuted}/>
        <Text style={[s.lbl,{marginTop:14}]}>DATE</Text>
        <TextInput style={s.input} value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor={C.textMuted}/>
        <Text style={[s.lbl,{marginTop:14}]}>CATEGORY</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginHorizontal:-18}}>
          {CAT_LIST.map(cat => (
            <TouchableOpacity key={cat} onPress={()=>setCategory(cat)}
              style={[s.catChip, category===cat&&{backgroundColor:CATEGORIES[cat].color+'33',borderColor:CATEGORIES[cat].color}]}>
              <Text style={{fontSize:15}}>{CATEGORIES[cat].icon}</Text>
              <Text style={[s.catTxt, category===cat&&{color:CATEGORIES[cat].color}]}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <Text style={[s.lbl,{marginTop:16}]}>NOTE</Text>
        <TextInput style={s.input} value={note} onChangeText={setNote} placeholder="Optional…" placeholderTextColor={C.textMuted}/>
        <TouchableOpacity style={[s.btn,(!amount||!merchant)&&{opacity:0.4}]} onPress={save} disabled={!amount||!merchant}>
          <Text style={s.btnTxt}>Add Expense</Text>
        </TouchableOpacity>
      </View>
      <View style={{height:30}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  scroll:    {flex:1,backgroundColor:C.bg},
  title:     {fontSize:22,fontWeight:'800',color:C.text,padding:20,paddingBottom:8},
  card:      {backgroundColor:C.surface,borderRadius:16,padding:18,marginHorizontal:16,borderWidth:1,borderColor:C.border},
  lbl:       {fontSize:10,color:C.textMuted,letterSpacing:1.2,marginBottom:8,fontWeight:'600'},
  bigInput:  {fontSize:36,fontWeight:'800',color:C.text,borderBottomWidth:2,borderBottomColor:C.accent,paddingBottom:8},
  input:     {backgroundColor:C.surface2,borderRadius:10,padding:13,color:C.text,fontSize:15,borderWidth:1,borderColor:C.border},
  catChip:   {flexDirection:'row',alignItems:'center',gap:5,paddingHorizontal:12,paddingVertical:8,borderRadius:20,backgroundColor:C.surface2,marginRight:8,marginLeft:2,borderWidth:1.5,borderColor:'transparent'},
  catTxt:    {color:C.textSub,fontSize:12,fontWeight:'500'},
  btn:       {marginTop:20,backgroundColor:C.accent,borderRadius:13,paddingVertical:15,alignItems:'center'},
  btnTxt:    {color:'#fff',fontSize:16,fontWeight:'700'},
  ok:        {margin:16,marginBottom:0,backgroundColor:'#22C55E22',borderRadius:12,padding:12,borderWidth:1,borderColor:'#22C55E'},
});
