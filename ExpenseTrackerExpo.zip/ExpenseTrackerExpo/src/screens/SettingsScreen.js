import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { C } from '../utils/colors';

export default function SettingsScreen({ settings, onSave }) {
  const [apiKey, setApiKey]       = useState(settings.apiKey||'');
  const [keywords, setKeywords]   = useState(settings.bankKeywords||'debited,debit,spent,paid,withdrawn,INR');
  const [done, setDone]           = useState(false);

  function save() {
    onSave({ apiKey, bankKeywords: keywords });
    setDone(true); setTimeout(()=>setDone(false),2000);
  }

  return (
    <ScrollView style={{flex:1,backgroundColor:C.bg}} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>Settings</Text>
      {done && <View style={s.ok}><Text style={{color:'#86EFAC',fontSize:14,fontWeight:'600',textAlign:'center'}}>✓ Saved</Text></View>}

      <View style={s.privCard}>
        <Text style={s.privTitle}>🔒 Privacy First</Text>
        <Text style={s.privTxt}>{'• SMS read locally on your device\n• Data stored in app only — never uploaded\n• AI parsing optional (uses your own API key)\n• Works 100% offline without API key'}</Text>
      </View>

      <View style={s.card}>
        <Text style={s.lbl}>BANK SMS KEYWORDS</Text>
        <Text style={s.hint}>Only SMS containing these words will be imported. Separate by commas.</Text>
        <TextInput style={s.input} value={keywords} onChangeText={setKeywords} autoCapitalize="none" placeholderTextColor={C.textMuted}/>
      </View>

      <View style={s.card}>
        <Text style={s.lbl}>CLAUDE API KEY (OPTIONAL)</Text>
        <Text style={s.hint}>For smarter AI parsing. Get free at console.anthropic.com. Leave blank for offline mode.</Text>
        <TextInput style={s.input} value={apiKey} onChangeText={setApiKey} placeholder="sk-ant-…" placeholderTextColor={C.textMuted} secureTextEntry autoCapitalize="none"/>
      </View>

      <TouchableOpacity style={s.btn} onPress={save}>
        <Text style={s.btnTxt}>Save Settings</Text>
      </TouchableOpacity>

      <View style={s.card}>
        <Text style={s.lbl}>SUPPORTED BANKS</Text>
        {[['AU Bank','✅'],['HDFC','✅'],['ICICI','✅'],['SBI','✅'],['Axis','✅'],['Kotak','✅'],['Others','Add keywords above']].map(([b,n])=>(
          <View key={b} style={{flexDirection:'row',justifyContent:'space-between',paddingVertical:8,borderBottomWidth:1,borderBottomColor:C.surface2}}>
            <Text style={{color:C.text,fontSize:13}}>🏦 {b}</Text>
            <Text style={{color:C.green,fontSize:12}}>{n}</Text>
          </View>
        ))}
      </View>
      <View style={{height:40}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  title:    {fontSize:22,fontWeight:'800',color:C.text,padding:20,paddingBottom:8},
  card:     {backgroundColor:C.surface,borderRadius:16,padding:18,marginHorizontal:16,marginBottom:12,borderWidth:1,borderColor:C.border},
  privCard: {backgroundColor:'#6366F111',borderRadius:16,padding:18,marginHorizontal:16,marginBottom:12,borderWidth:1,borderColor:'#6366F144'},
  privTitle:{color:C.text,fontSize:15,fontWeight:'700',marginBottom:8},
  privTxt:  {color:C.textSub,fontSize:13,lineHeight:22},
  lbl:      {fontSize:10,color:C.textMuted,letterSpacing:1.2,marginBottom:6,fontWeight:'600'},
  hint:     {color:C.textSub,fontSize:12,marginBottom:10,lineHeight:17},
  input:    {backgroundColor:C.surface2,borderRadius:10,padding:13,color:C.text,fontSize:14,borderWidth:1,borderColor:C.border},
  btn:      {margin:16,backgroundColor:C.accent,borderRadius:13,paddingVertical:15,alignItems:'center'},
  btnTxt:   {color:'#fff',fontSize:16,fontWeight:'700'},
  ok:       {margin:16,marginBottom:0,backgroundColor:'#22C55E22',borderRadius:12,padding:12,borderWidth:1,borderColor:'#22C55E'},
});
