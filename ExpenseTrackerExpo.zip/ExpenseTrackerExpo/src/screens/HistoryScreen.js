import React, { useMemo, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, TextInput } from 'react-native';
import { C, CATEGORIES, MONTHS } from '../utils/colors';
import { fmt } from '../utils/storage';

export default function HistoryScreen({ expenses, selectedMonth, onDelete }) {
  const [q, setQ] = useState('');
  const monthExp  = useMemo(() => expenses.filter(e=>e.date?.startsWith(selectedMonth)),[expenses,selectedMonth]);
  const filtered  = useMemo(() => {
    if (!q.trim()) return monthExp;
    const ql = q.toLowerCase();
    return monthExp.filter(e=>e.merchant?.toLowerCase().includes(ql)||e.category?.toLowerCase().includes(ql));
  },[monthExp,q]);
  const total = monthExp.reduce((s,e)=>s+e.amount,0);
  const [yr,mo] = selectedMonth.split('-');

  return (
    <View style={{flex:1,backgroundColor:C.bg}}>
      <View style={s.hdr}>
        <Text style={s.title}>{MONTHS[+mo-1]} {yr}</Text>
        <Text style={{color:C.textSub,fontSize:13}}>Total: <Text style={{color:C.orange,fontWeight:'700'}}>{fmt(total)}</Text></Text>
      </View>
      <View style={s.searchBox}>
        <Text style={{fontSize:16,marginRight:6}}>🔍</Text>
        <TextInput style={s.searchInput} value={q} onChangeText={setQ} placeholder="Search…" placeholderTextColor={C.textMuted}/>
      </View>
      <FlatList
        data={filtered} keyExtractor={e=>e.id}
        contentContainerStyle={{padding:16,paddingBottom:30}}
        ListEmptyComponent={<Text style={{color:C.textMuted,textAlign:'center',marginTop:40,fontSize:14}}>No expenses</Text>}
        renderItem={({item:e}) => (
          <View style={s.row}>
            <View style={[s.ico,{backgroundColor:(CATEGORIES[e.category]?.color||'#999')+'22'}]}>
              <Text style={{fontSize:18}}>{CATEGORIES[e.category]?.icon||'📦'}</Text>
            </View>
            <View style={{flex:1}}>
              <Text style={s.mer} numberOfLines={1}>{e.merchant}</Text>
              <Text style={s.sub}>{e.category} · {e.date}</Text>
            </View>
            <Text style={s.amt}>{fmt(e.amount)}</Text>
            <TouchableOpacity onPress={()=>onDelete(e.id)} style={{padding:6}}>
              <Text style={{color:C.textMuted,fontSize:20}}>×</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  hdr:       {flexDirection:'row',justifyContent:'space-between',alignItems:'center',padding:20,paddingBottom:12},
  title:     {fontSize:22,fontWeight:'800',color:C.text},
  searchBox: {flexDirection:'row',alignItems:'center',backgroundColor:C.surface,borderRadius:12,marginHorizontal:16,marginBottom:8,paddingHorizontal:12,borderWidth:1,borderColor:C.border},
  searchInput:{flex:1,color:C.text,fontSize:14,paddingVertical:12},
  row:       {flexDirection:'row',alignItems:'center',backgroundColor:C.surface,borderRadius:13,padding:12,marginBottom:8,borderWidth:1,borderColor:C.border,gap:10},
  ico:       {width:38,height:38,borderRadius:10,alignItems:'center',justifyContent:'center'},
  mer:       {color:C.text,fontSize:14,fontWeight:'600'},
  sub:       {color:C.textSub,fontSize:11,marginTop:2},
  amt:       {color:C.orange,fontSize:14,fontWeight:'700'},
});
