import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator, Switch } from 'react-native';
import { C, CATEGORIES } from '../utils/colors';
import { fmt } from '../utils/storage';
import { useSMS } from '../hooks/useSMS';

export default function SyncScreen({ onSave, settings }) {
  const { readSMS, loading, error, setError } = useSMS();
  const [preview, setPreview]   = useState([]);
  const [selected, setSelected] = useState({});
  const [daysBack, setDaysBack] = useState(30);
  const [useAI, setUseAI]       = useState(false);
  const [done, setDone]         = useState(false);

  async function handleSync() {
    setPreview([]); setSelected({}); setDone(false); setError('');
    const results = await readSMS({ keywords: settings.bankKeywords, daysBack, useAI: useAI && !!settings.apiKey, apiKey: settings.apiKey });
    if (results.length) {
      setPreview(results);
      const sel = {}; results.forEach(r => sel[r.id]=true); setSelected(sel);
    }
  }

  function handleConfirm() {
    const toSave = preview.filter(p => selected[p.id]);
    if (!toSave.length) return;
    onSave(toSave);
    setDone(true); setPreview([]);
  }

  return (
    <ScrollView style={s.scroll} showsVerticalScrollIndicator={false}>
      <View style={s.hero}>
        <Text style={{fontSize:52}}>📱</Text>
        <Text style={s.heroTitle}>Sync Bank SMS</Text>
        <Text style={s.heroSub}>Reads messages directly from your phone. Nothing leaves your device.</Text>
      </View>

      {/* Days back */}
      <View style={s.card}>
        <Text style={s.lbl}>LOOK BACK PERIOD</Text>
        <View style={{flexDirection:'row',gap:8}}>
          {[7,15,30,60,90].map(d => (
            <TouchableOpacity key={d} onPress={()=>setDaysBack(d)}
              style={[s.chip, daysBack===d&&s.chipA]}>
              <Text style={[s.chipTxt, daysBack===d&&s.chipTxtA]}>{d}d</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* AI toggle */}
      {!!settings.apiKey && (
        <View style={s.card}>
          <View style={{flexDirection:'row',alignItems:'center',gap:12}}>
            <View style={{flex:1}}>
              <Text style={{color:C.text,fontSize:14,fontWeight:'600'}}>AI Parsing</Text>
              <Text style={{color:C.textSub,fontSize:12,marginTop:3}}>Uses Claude API for smarter merchant names & categories</Text>
            </View>
            <Switch value={useAI} onValueChange={setUseAI} trackColor={{true:C.accent}} thumbColor={useAI?'#fff':C.textMuted}/>
          </View>
        </View>
      )}

      <TouchableOpacity style={[s.syncBtn,loading&&{opacity:0.5}]} onPress={handleSync} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff"/> : <Text style={s.syncBtnTxt}>📥  Read Bank SMS</Text>}
      </TouchableOpacity>

      {!!error && <View style={s.errBox}><Text style={{color:'#FCA5A5',fontSize:13,lineHeight:18}}>⚠️  {error}</Text></View>}
      {done && <View style={s.okBox}><Text style={{color:'#86EFAC',fontSize:14,fontWeight:'600',textAlign:'center'}}>✓ Expenses saved!</Text></View>}

      {preview.length > 0 && (
        <View style={s.card}>
          <Text style={s.lbl}>FOUND {preview.length} TRANSACTIONS</Text>
          {preview.map((p,i) => (
            <TouchableOpacity key={p.id} onPress={()=>setSelected(sel=>({...sel,[p.id]:!sel[p.id]}))} style={s.txRow}>
              <View style={[s.checkbox,selected[p.id]&&{backgroundColor:C.accent,borderColor:C.accent}]}>
                {selected[p.id] && <Text style={{color:'#fff',fontSize:11,fontWeight:'700'}}>✓</Text>}
              </View>
              <View style={[s.txIco,{backgroundColor:(CATEGORIES[p.category]?.color||'#999')+'22'}]}>
                <Text style={{fontSize:17}}>{CATEGORIES[p.category]?.icon||'📦'}</Text>
              </View>
              <View style={{flex:1}}>
                <Text style={{color:C.text,fontSize:14,fontWeight:'600'}}>{p.merchant}</Text>
                <Text style={{color:C.textSub,fontSize:11,marginTop:1}}>{p.category} · {p.date}</Text>
              </View>
              <Text style={{color:C.orange,fontSize:14,fontWeight:'700'}}>{fmt(p.amount)}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity style={s.confirmBtn} onPress={handleConfirm}>
            <Text style={s.confirmTxt}>Save {Object.values(selected).filter(Boolean).length} Selected</Text>
          </TouchableOpacity>
        </View>
      )}
      <View style={{height:30}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  scroll:      {flex:1,backgroundColor:C.bg},
  hero:        {alignItems:'center',padding:28,paddingBottom:16},
  heroTitle:   {fontSize:22,fontWeight:'800',color:C.text,marginTop:8},
  heroSub:     {color:C.textSub,fontSize:13,textAlign:'center',marginTop:6,lineHeight:19},
  card:        {backgroundColor:C.surface,borderRadius:16,padding:18,marginHorizontal:16,marginBottom:12,borderWidth:1,borderColor:C.border},
  lbl:         {fontSize:10,color:C.textMuted,letterSpacing:1.2,marginBottom:10,fontWeight:'600'},
  chip:        {paddingHorizontal:16,paddingVertical:8,borderRadius:20,backgroundColor:C.surface2},
  chipA:       {backgroundColor:C.accent},
  chipTxt:     {color:C.textSub,fontSize:13,fontWeight:'500'},
  chipTxtA:    {color:'#fff',fontWeight:'700'},
  syncBtn:     {margin:16,backgroundColor:C.accent,borderRadius:14,paddingVertical:16,alignItems:'center'},
  syncBtnTxt:  {color:'#fff',fontSize:16,fontWeight:'700'},
  errBox:      {margin:16,backgroundColor:'#EF444422',borderRadius:12,padding:14,borderWidth:1,borderColor:'#EF4444'},
  okBox:       {margin:16,backgroundColor:'#22C55E22',borderRadius:12,padding:14,borderWidth:1,borderColor:'#22C55E'},
  txRow:       {flexDirection:'row',alignItems:'center',paddingVertical:10,borderBottomWidth:1,borderBottomColor:C.surface2,gap:10},
  checkbox:    {width:22,height:22,borderRadius:6,borderWidth:1.5,borderColor:C.accent,alignItems:'center',justifyContent:'center'},
  txIco:       {width:36,height:36,borderRadius:9,alignItems:'center',justifyContent:'center'},
  confirmBtn:  {marginTop:14,backgroundColor:C.accent,borderRadius:12,paddingVertical:14,alignItems:'center'},
  confirmTxt:  {color:'#fff',fontSize:15,fontWeight:'700'},
});
