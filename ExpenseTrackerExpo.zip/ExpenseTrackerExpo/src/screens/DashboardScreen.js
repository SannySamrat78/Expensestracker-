import React, { useMemo } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { C, CATEGORIES, MONTHS } from '../utils/colors';
import { fmt } from '../utils/storage';

export default function DashboardScreen({ expenses, selectedMonth, setMonth, onDelete }) {
  const monthExp = useMemo(() => expenses.filter(e => e.date?.startsWith(selectedMonth)), [expenses, selectedMonth]);
  const total    = useMemo(() => monthExp.reduce((s,e) => s+e.amount, 0), [monthExp]);

  const catTotals = useMemo(() =>
    Object.keys(CATEGORIES)
      .map(cat => ({ cat, sum: monthExp.filter(e=>e.category===cat).reduce((s,e)=>s+e.amount,0) }))
      .filter(c => c.sum > 0)
      .sort((a,b) => b.sum - a.sum)
      .map(c => ({ ...c, pct: total ? Math.round((c.sum/total)*100) : 0 })),
    [monthExp, total]
  );

  const dailyMap = useMemo(() => {
    const m = {};
    monthExp.forEach(e => { const d=e.date?.slice(8,10); if(d) m[d]=(m[d]||0)+e.amount; });
    return m;
  }, [monthExp]);
  const dailyMax = Math.max(...Object.values(dailyMap), 1);

  const allMonths = useMemo(() => {
    const s = new Set(expenses.map(e=>e.date?.slice(0,7)).filter(Boolean));
    s.add(selectedMonth);
    return [...s].sort().reverse();
  }, [expenses, selectedMonth]);

  const [yr, mo] = selectedMonth.split('-');
  const daysInMonth = new Date(+yr, +mo, 0).getDate();

  return (
    <ScrollView style={s.scroll} showsVerticalScrollIndicator={false}>
      {/* Month selector */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.monthRow}>
        {allMonths.map(m => {
          const [y,n] = m.split('-');
          const active = m === selectedMonth;
          return (
            <TouchableOpacity key={m} onPress={()=>setMonth(m)} style={[s.mTab, active&&s.mTabA]}>
              <Text style={[s.mTabTxt, active&&s.mTabTxtA]}>{MONTHS[+n-1]} {y}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Total */}
      <View style={s.card}>
        <Text style={s.lbl}>TOTAL SPENT · {MONTHS[+mo-1].toUpperCase()} {yr}</Text>
        <Text style={s.bigNum}>{fmt(total)}</Text>
        <View style={s.pillRow}>
          <View style={s.pill}><Text style={s.pillTxt}>🧾 {monthExp.length} txns</Text></View>
          {monthExp.length > 0 && <View style={s.pill}><Text style={s.pillTxt}>📅 avg {fmt(total/daysInMonth)}/day</Text></View>}
        </View>
      </View>

      {/* Sparkline */}
      {Object.keys(dailyMap).length > 0 && (
        <View style={s.card}>
          <Text style={s.lbl}>DAILY SPENDING</Text>
          <View style={s.spark}>
            {Array.from({length:daysInMonth},(_,i)=>{
              const d=String(i+1).padStart(2,'0');
              const v=dailyMap[d]||0;
              const h=v?Math.max(4,Math.round((v/dailyMax)*48)):2;
              return <View key={d} style={[s.sparkBar,{height:h,backgroundColor:v?C.accent:C.surface2}]}/>;
            })}
          </View>
        </View>
      )}

      {/* Categories */}
      {catTotals.length > 0 && (
        <View style={s.card}>
          <Text style={s.lbl}>BY CATEGORY</Text>
          {catTotals.map(({cat,sum,pct}) => (
            <View key={cat} style={s.catRow}>
              <Text style={s.catIcon}>{CATEGORIES[cat].icon}</Text>
              <Text style={s.catName}>{cat}</Text>
              <View style={s.catBarBg}>
                <View style={[s.catBarFill,{width:`${pct}%`,backgroundColor:CATEGORIES[cat].color}]}/>
              </View>
              <Text style={s.catPct}>{pct}%</Text>
              <Text style={s.catAmt}>{fmt(sum)}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Recent */}
      <View style={s.card}>
        <Text style={s.lbl}>RECENT</Text>
        {monthExp.length === 0
          ? <Text style={s.empty}>No expenses — go to Sync SMS tab</Text>
          : monthExp.slice(0,8).map(e => (
            <View key={e.id} style={s.txRow}>
              <View style={[s.txIco,{backgroundColor:(CATEGORIES[e.category]?.color||'#999')+'22'}]}>
                <Text style={{fontSize:18}}>{CATEGORIES[e.category]?.icon||'📦'}</Text>
              </View>
              <View style={{flex:1}}>
                <Text style={s.txMer} numberOfLines={1}>{e.merchant}</Text>
                <Text style={s.txSub}>{e.category} · {e.date?.slice(5)}</Text>
              </View>
              <Text style={s.txAmt}>{fmt(e.amount)}</Text>
              <TouchableOpacity onPress={()=>onDelete(e.id)} style={{padding:6}}>
                <Text style={{color:C.textMuted,fontSize:20}}>×</Text>
              </TouchableOpacity>
            </View>
          ))
        }
      </View>
      <View style={{height:20}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  scroll:     {flex:1,backgroundColor:C.bg},
  monthRow:   {paddingHorizontal:16,paddingVertical:12,gap:8,flexDirection:'row'},
  mTab:       {paddingHorizontal:14,paddingVertical:7,borderRadius:20,backgroundColor:C.surface2},
  mTabA:      {backgroundColor:C.accent},
  mTabTxt:    {color:C.textSub,fontSize:13,fontWeight:'500'},
  mTabTxtA:   {color:'#fff',fontWeight:'700'},
  card:       {backgroundColor:C.surface,borderRadius:16,padding:18,marginHorizontal:16,marginBottom:12,borderWidth:1,borderColor:C.border},
  lbl:        {fontSize:10,color:C.textMuted,letterSpacing:1.2,marginBottom:10,fontWeight:'600'},
  bigNum:     {fontSize:42,fontWeight:'800',color:C.text,letterSpacing:-1.5},
  pillRow:    {flexDirection:'row',gap:8,marginTop:12},
  pill:       {backgroundColor:C.surface2,borderRadius:20,paddingHorizontal:10,paddingVertical:4},
  pillTxt:    {color:C.textSub,fontSize:12},
  spark:      {flexDirection:'row',alignItems:'flex-end',height:52,gap:2},
  sparkBar:   {flex:1,borderRadius:2},
  catRow:     {flexDirection:'row',alignItems:'center',marginBottom:8,gap:6},
  catIcon:    {fontSize:16,width:22},
  catName:    {color:C.text,fontSize:12,width:90},
  catBarBg:   {flex:1,height:5,backgroundColor:C.surface2,borderRadius:99},
  catBarFill: {height:5,borderRadius:99},
  catPct:     {color:C.textMuted,fontSize:11,width:28,textAlign:'right'},
  catAmt:     {color:C.textSub,fontSize:12,width:58,textAlign:'right'},
  txRow:      {flexDirection:'row',alignItems:'center',paddingVertical:10,borderBottomWidth:1,borderBottomColor:C.surface2,gap:10},
  txIco:      {width:38,height:38,borderRadius:10,alignItems:'center',justifyContent:'center'},
  txMer:      {color:C.text,fontSize:14,fontWeight:'600'},
  txSub:      {color:C.textSub,fontSize:11,marginTop:2},
  txAmt:      {color:C.orange,fontSize:14,fontWeight:'700'},
  empty:      {color:C.textMuted,textAlign:'center',padding:20,fontSize:13},
});
