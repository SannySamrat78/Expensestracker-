export const C = {
  bg:        '#0B0B10',
  surface:   '#13131C',
  surface2:  '#1A1A27',
  border:    '#22223A',
  accent:    '#6366F1',
  green:     '#22C55E',
  orange:    '#F97316',
  red:       '#EF4444',
  text:      '#F1F5F9',
  textSub:   '#64748B',
  textMuted: '#334155',
};

export const CATEGORIES = {
  Food:          { icon: '🍔', color: '#F97316' },
  Shopping:      { icon: '🛍️',  color: '#8B5CF6' },
  Transport:     { icon: '🚗', color: '#3B82F6' },
  Bills:         { icon: '⚡', color: '#EAB308' },
  Health:        { icon: '💊', color: '#10B981' },
  Entertainment: { icon: '🎬', color: '#EC4899' },
  'ATM/Cash':    { icon: '💵', color: '#6B7280' },
  Other:         { icon: '📦', color: '#94A3B8' },
};

export const CAT_LIST = Object.keys(CATEGORIES);
export const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
