// Offline regex parser — works with no internet, no API key
// Covers AU Bank, HDFC, ICICI, SBI, Axis, Kotak, Paytm

function parseDate(str, fmt) {
  if (!str) return new Date().toISOString().slice(0, 10);
  try {
    let d, m, y;
    if (/\d{2}[-\/]\d{2}[-\/]\d{4}/.test(str)) {
      const sep = str.includes('-') ? '-' : '/';
      [d, m, y] = str.split(sep);
    } else if (/\d{2}[-\/]\d{2}[-\/]\d{2}$/.test(str)) {
      const sep = str.includes('-') ? '-' : '/';
      [d, m, y] = str.split(sep);
      y = '20' + y;
    } else if (/\d{2}[A-Za-z]{3}\d{2,4}/.test(str)) {
      const months = {jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12};
      d = str.slice(0,2);
      m = months[str.slice(2,5).toLowerCase()] || 1;
      y = str.length > 7 ? str.slice(5) : '20' + str.slice(5);
    } else {
      return new Date().toISOString().slice(0,10);
    }
    return `${String(y).padStart(4,'0')}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
  } catch { return new Date().toISOString().slice(0,10); }
}

function cleanMerchant(raw) {
  if (!raw) return 'Unknown';
  return raw
    .replace(/UPI\//gi,'').replace(/\bLTD\.?\b|\bPVT\.?\b|\bINC\.?\b/gi,'')
    .replace(/[*#|]/g,' ').replace(/\s+/g,' ').trim()
    .split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ')
    .slice(0,30);
}

function guessCategory(merchant) {
  const m = merchant.toLowerCase();
  if (/zomato|swiggy|food|restaurant|cafe|pizza|burger|biryani|dhaba|eat|kitchen|dabba/.test(m)) return 'Food';
  if (/amazon|flipkart|myntra|meesho|ajio|shop|store|mart|mall|nykaa|blinkit|zepto/.test(m)) return 'Shopping';
  if (/uber|ola|rapido|metro|petrol|fuel|auto|cab|bus|railway|irctc|toll|parking/.test(m)) return 'Transport';
  if (/electricity|water|gas|bill|recharge|airtel|jio|vi |bsnl|broadband|dth|postpaid/.test(m)) return 'Bills';
  if (/apollo|medplus|pharmacy|doctor|hospital|clinic|health|med|pharma|lab/.test(m)) return 'Health';
  if (/netflix|prime|hotstar|spotify|movie|cinema|pvr|inox|game|youtube/.test(m)) return 'Entertainment';
  if (/atm|cash|withdraw/.test(m)) return 'ATM/Cash';
  return 'Other';
}

const PATTERNS = [
  // AU Bank: INR 365.98 were spent on your AU Bank Credit Card xx3439 at UPI/ZOMATO LTD on 21-06-2026
  { re: /INR\s+([\d,]+\.?\d*)\s+were\s+spent.*?at\s+(?:UPI\/)?([A-Z0-9 &.'\-]+?)\s+on\s+(\d{2}-\d{2}-\d{2,4})/i, a:1, mer:2, dt:3 },
  // HDFC: Rs.450.00 debited from A/c XX1234 on 22-06-26 for UPI/Merchant
  { re: /Rs\.?\s*([\d,]+\.?\d*)\s+(?:has been\s+)?debited.*?on\s+(\d{2}[-\/]\d{2}[-\/]\d{2,4}).*?(?:UPI\/)?([A-Za-z0-9 &.'\-]+?)(?:\.|$)/i, a:1, dt:2, mer:3 },
  // ICICI/Axis: A/c debited with Rs 500 on 22/06/2026 for Swiggy
  { re: /debited\s+with\s+Rs\.?\s*([\d,]+\.?\d*).*?on\s+(\d{2}[-\/]\d{2}[-\/]\d{2,4}).*?for\s+([A-Za-z0-9 &.'\-]+?)(?:\.|$)/i, a:1, dt:2, mer:3 },
  // SBI: debited by Rs.500 on 22Jun26 transfer to Merchant
  { re: /debited.*?(?:Rs\.?|INR)\s*([\d,]+\.?\d*)\s+on\s+(\d{2}[A-Za-z]{3}\d{2,4}).*?(?:to|at|for)\s+([A-Za-z0-9 &.'\-]+?)(?:\.|$)/i, a:1, dt:2, mer:3 },
  // Generic debit with amount
  { re: /(?:debited|spent|paid|withdrawn|deducted).*?(?:Rs\.?|INR|₹)\s*([\d,]+\.?\d*)/i, a:1, dt:null, mer:null },
];

export function parseSMSLocally(body) {
  for (const p of PATTERNS) {
    const m = body.match(p.re);
    if (!m) continue;
    const amount = parseFloat((m[p.a] || '0').replace(/,/g,''));
    if (!amount || amount <= 0) continue;
    const merchant = cleanMerchant(p.mer ? m[p.mer] : '');
    const date = p.dt ? parseDate(m[p.dt]) : new Date().toISOString().slice(0,10);
    return [{ amount, merchant, category: guessCategory(merchant), date, note: body.slice(0,100) }];
  }
  return [];
}

export function isBankSMS(body, keywords) {
  const kw = (keywords || 'debited,debit,spent,paid,withdrawn,INR').split(',');
  return kw.some(k => body.toLowerCase().includes(k.trim().toLowerCase()));
}

export async function parseWithAI(bodies, apiKey) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 2000,
      messages: [{
        role: 'user',
        content: `Extract expenses from these Indian bank SMS. Return ONLY JSON array.
Each: {amount:number, merchant:string, category:"Food|Shopping|Transport|Bills|Health|Entertainment|ATM/Cash|Other", date:"YYYY-MM-DD", note:string}
Skip credits. Return [] if none.
SMS:
${bodies.slice(0,20).map((b,i)=>`${i+1}. ${b}`).join('\n')}`,
      }],
    }),
  });
  const data = await res.json();
  const text = data.content?.map(c => c.text||'').join('') || '[]';
  return JSON.parse(text.replace(/```json|```/g,'').trim());
}
