import AsyncStorage from '@react-native-async-storage/async-storage';

const EXPENSES_KEY = 'expenses_v1';
const SETTINGS_KEY = 'settings_v1';

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);
export const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });

export async function loadExpenses() {
  try {
    const raw = await AsyncStorage.getItem(EXPENSES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export async function saveExpenses(list) {
  try { await AsyncStorage.setItem(EXPENSES_KEY, JSON.stringify(list)); } catch {}
}

export async function loadSettings() {
  try {
    const raw = await AsyncStorage.getItem(SETTINGS_KEY);
    return raw ? JSON.parse(raw) : {
      apiKey: '',
      bankKeywords: 'debited,debit,spent,paid,withdrawn,INR',
    };
  } catch {
    return { apiKey: '', bankKeywords: 'debited,debit,spent,paid,withdrawn,INR' };
  }
}

export async function saveSettings(s) {
  try { await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch {}
}
